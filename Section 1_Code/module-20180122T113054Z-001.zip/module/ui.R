
fluidPage(
  
  titlePanel("Time series"),

  fluidRow(
    column(6, yearFilterUI("moviesApplicationOne", 
                           "Year selector (movies)"), 
           plotOutput("yearPlot")),
    column(6, yearFilterUI("moviesApplicationTwo", 
                           "Year selector (Nile)"), 
           plotOutput("yearPlotTwo"))
  ),

  fluidRow(
    h3("Movie picker"),
  
    uiOutput("listMovies"),
    tableOutput("moviePicker")
  )
)