
library(tidyverse)
library(ggplot2movies)

data(Nile)

nileData = tibble(year = time(Nile), flow = Nile)

yearFilterUI = function(id, label){
  
  ns = NS(id)
  
  tagList(
    
    sliderInput(ns("year"), label = label, 
                min = 1893, max = 2005,
                value = c(1945, 2005), sep = ""),
    
    selectInput(ns("smooth"), "Smooth?", 
                choices = c("LOESS" = "loess", 
                            "Linear" = "lm"))
  )
}

yearFilter = function(input, output, session, passData){
  
  plotData = reactive({
    
    names(passData) = c("x", "y")
    
    passData %>% 
      filter(x %in% seq(input$year[1], input$year[2]))
  })
  
  timeSeries = summarise(group_by(plotData(), x), 
                           m = mean(y, na.rm = TRUE))
  
  ggplot(timeSeries[complete.cases(timeSeries), ],
         aes(x = x, y = m)) +
    geom_line() +
    scale_y_continuous(labels = scales::comma) +
    geom_smooth(method = input$smooth)
  
}
