
library(scales)
library(rlang)

function(input, output) {
  
  output$yearPlot = renderPlot({
    
    callModule(yearFilter, "moviesApplicationOne", 
               passData = movies[c("year", "budget")])
  })
  
  output$yearPlotTwo = renderPlot({
    
    callModule(yearFilter, "moviesApplicationTwo", 
               passData = nileData)
  })
  
  output$listMovies = renderUI({
    
    selectInput("pickMovie", "Pick a movie", 
                choices = movies %>% 
                  sample_n(10) %>%
                  select(title)
    )
  })
  
  output$moviePicker = renderTable({
    
    validate(
      need(input$pickMovie, "Loading...")
    )
    
    filter(movies, title == input$pickMovie)
  })
}
