
library(ggplot2movies)
library(tidyverse)
library(scales)
library(rlang)

function(input, output) {
  
  moviesSubset = reactive({
    
    movies %>% filter(year %in% seq(input$year[1], input$year[2]))
    
  })
  
  budgetYearFunction = function(genre) {
    
    budgetByYear = moviesSubset() %>% 
      filter(UQ(sym(genre)) == 1) %>%
      group_by(year) %>%
      summarise(m = mean(budget, na.rm = TRUE))
    
    ggplot(budgetByYear[complete.cases(budgetByYear), ], 
           aes(x = year, y = m)) + 
      geom_line() + 
      scale_y_continuous(labels = scales::comma) + 
      geom_smooth(method = "loess")
      
  }
  
  output$budgetYearAction = renderPlot({
    
    budgetYearFunction("Action")
  })
  
  output$budgetYearComedy = renderPlot({
    
    budgetYearFunction("Comedy")
  })
  
  output$listMovies = renderUI({
    
    selectInput("pickMovie", "Pick a movie", 
                choices = moviesSubset() %>% 
                  sample_n(10) %>%
                  select(title)
    )
  })
  
  output$moviePicker = renderTable({
    
    filter(moviesSubset(), title == input$pickMovie)
    
  })
  
}
