
fluidPage(
  
  titlePanel("Movies explorer"),
  
  sidebarLayout(
    sidebarPanel(
      sliderInput("year", "Year", min = 1893, max = 2005,
                  value = c(1945, 2005), sep = ""),
      uiOutput("listMovies")
    ),
    
    mainPanel(
      tabsetPanel(id = "theTabs",
                  tabPanel("Budgets over time- Action", value = "plot", 
                           plotOutput("budgetYearAction")),
                  tabPanel("Budgets over time- Comedy", value = "plot", 
                           plotOutput("budgetYearComedy")),
                  tabPanel("Movie picker", value = "table", 
                           tableOutput("moviePicker"))
      )
    )
  )
)